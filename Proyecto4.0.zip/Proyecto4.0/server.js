const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

const ARCHIVO = path.join(__dirname, 'datos.json');

app.use(express.json());
app.use(express.static(__dirname)); // Sirve los HTML, JS, CSS, etc.

app.post('/guardar', (req, res) => {
  const nuevoDato = req.body;
  let datosGuardados = [];

  if (fs.existsSync(ARCHIVO)) {
    const contenido = fs.readFileSync(ARCHIVO, 'utf8');
    datosGuardados = JSON.parse(contenido);
  }

  datosGuardados.push(nuevoDato);
  fs.writeFileSync(ARCHIVO, JSON.stringify(datosGuardados, null, 2));

  res.json({ mensaje: "Datos guardados correctamente" });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🟢 Servidor activo en http://localhost:${PORT}`);
});

 //http://localhost:3000/Proyecto4.0/paginaprincipal.html -->