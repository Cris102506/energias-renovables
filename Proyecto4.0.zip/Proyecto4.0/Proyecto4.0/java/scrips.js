document.getElementById('boton').addEventListener('click', function () {
    const nav = document.querySelector('.nav-menu');
    const overlay = document.querySelector('.overlay');
    nav.classList.toggle('active');
    overlay.classList.toggle('active');
    this.classList.toggle('menuabierto'); // Mueve el botón a la derecha del menú

    if (nav.classList.contains('active')) {
        this.innerHTML = '&times;';
    } else {
        this.innerHTML = '&#9776;';
    }
});

// Opcional: cerrar menú al hacer clic en el overlay
document.querySelector('.overlay').addEventListener('click', function () {
    document.querySelector('.nav-menu').classList.remove('active');
    this.classList.remove('active');
    const boton = document.getElementById('boton');
    boton.innerHTML = '&#9776;';
    boton.classList.remove('menuabierto');
});

document.querySelectorAll('.barra-vertical').forEach(barra => {
    barra.addEventListener('click', function() {
        // Quitar la clase activa de todas las barras
        document.querySelectorAll('.barra-vertical-activa').forEach(activa => {
            activa.classList.remove('barra-vertical-activa');
            activa.classList.add('barra-vertical');
        });
        // Cambiar la barra clickeada a activa
        this.classList.remove('barra-vertical');
        this.classList.add('barra-vertical-activa');
    });
});

 document.addEventListener("DOMContentLoaded", () => {
    const cuadros = document.querySelectorAll(".cuadro");
    const bloques = document.querySelectorAll(".bloqueenergia");

    cuadros.forEach((cuadro, index) => {
      cuadro.addEventListener("click", () => {
        // Quitar clases activas anteriores
        cuadros.forEach(c => c.classList.remove("activo"));
        bloques.forEach(b => b.classList.remove("bloqueenergiaactivo"));

        // Activar cuadro e ítem correspondiente
        cuadro.classList.add("activo");
        bloques[index].classList.add("bloqueenergiaactivo");
      });
    });
  });


document.getElementById("calculadoraForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const consumoTotal = parseFloat(document.getElementById("consumo").value) || 0;
    const renovable = parseFloat(document.getElementById("renovable").value) || 0;
    const estrato = parseInt(document.getElementById("Estrato").value);

    const consumoNeto = Math.max(consumoTotal - renovable, 0);
    const limiteSubsidio = 130;

    let total = 0;

    // Tarifas por estrato (Propiedad EPM) en $/kWh
    const tarifas = {
        1: { subsidio: 372.38, plena: 765.44 },
        2: { subsidio: 496.21, plena: 836.50 },
        3: { subsidio: 610.44, plena: 836.50 },
        4: { tarifaPlena: 836.50 },
        5: { tarifaPlena: 1003.81, contribucion: 0.2 },
        6: { tarifaPlena: 1003.81, contribucion: 0.2 }
    };

    let detalle = "";

    if (estrato >= 1 && estrato <= 3) {
        if (consumoNeto <= limiteSubsidio) {
            total = consumoNeto * tarifas[estrato].subsidio;
            detalle = `
                <p>Aplicado subsidio por estrato ${estrato}.</p>
                <p>Tarifa subsidiada: $${tarifas[estrato].subsidio.toFixed(2)} x kWh</p>
            `;
        } else {
            total = consumoNeto * tarifas[estrato].plena;
            detalle = `
                <p style="color: red;"><strong>No se aplica subsidio</strong> porque el consumo neto supera los ${limiteSubsidio} kWh.</p>
                <p>Tarifa plena: $${tarifas[estrato].plena.toFixed(2)} x kWh</p>
            `;
        }
    } else if (estrato === 4) {
        total = consumoNeto * tarifas[estrato].tarifaPlena;
        detalle = `
            <p>Tarifa plena sin subsidio ni contribución.</p>
            <p>Tarifa: $${tarifas[estrato].tarifaPlena.toFixed(2)} x kWh</p>
        `;
    } else if (estrato === 5 || estrato === 6) {
        const base = consumoNeto * tarifas[estrato].tarifaPlena;
        const contribucion = base * tarifas[estrato].contribucion;
        total = base + contribucion;
        detalle = `
            <p>Tarifa plena: $${tarifas[estrato].tarifaPlena.toFixed(2)} x kWh</p>
            <p>Contribución del 20%: $${contribucion.toFixed(2)}</p>
        `;
    }

    document.getElementById("resultado").innerHTML = `
        <h3>Resultado:</h3>
        <p>Consumo neto: <strong>${consumoNeto.toFixed(2)} kWh</strong></p>
        ${detalle}
        <p><strong>Total a pagar: $${total.toFixed(2)}</strong></p>
    `;
});

document.querySelectorAll('.cuadro').forEach(cuadro => {
    cuadro.addEventListener('click', function() {
        // Oculta todos los bloques
        document.querySelectorAll('.bloqueenergiaactivo').forEach(b => {
            b.classList.remove('bloqueenergiaactivo');
            b.classList.add('bloqueenergia');
        });
        // Muestra solo el bloque correspondiente
        const target = this.getAttribute('data-target');
        if(target) {
            const bloque = document.getElementById(target);
            if(bloque) {
                bloque.classList.remove('bloqueenergia');
                bloque.classList.add('bloqueenergiaactivo');
            }
        }
    });
});

function recomendarEnergia() {
 
        const estrato = parseInt(document.getElementById("estrato").value);
        const tipoVivienda = document.getElementById("tipoVivienda").value;
        const tipoTecho = document.getElementById("tipoTecho").value;
        const presupuesto = parseInt(
          document.getElementById("presupuesto").value
        );
        const ciudad = document.getElementById("ciudad").value.trim();

        let recomendacion = "";

        if (tipoTecho === "ninguno") {
          recomendacion =
            "Dado que no se cuenta con un techo adecuado, considera energía eólica pequeña o comunidad solar compartida.";
        } else if (presupuesto < 3000000) {
          recomendacion =
            "Con un presupuesto bajo, se recomienda iniciar con paneles solares pequeños o kits solares portátiles para iluminación y carga básica.";
        } else if (presupuesto >= 3000000 && presupuesto <= 8000000) {
          recomendacion =
            "Puedes instalar un sistema fotovoltaico básico para el hogar. Revisa si hay subsidios locales en " +
            ciudad +
            ".";
        } else {
          recomendacion =
            "Tienes un buen presupuesto. Puedes considerar paneles solares con baterías de respaldo o sistemas híbridos con energía eólica si estás en zona rural.";
        }

        if (tipoVivienda === "apartamento" && tipoTecho !== "plano") {
          recomendacion +=
            " Como vives en apartamento, verifica la posibilidad de instalar en áreas comunes o usar soluciones comunitarias.";
        }

        document.getElementById(
          "resultado"
        ).innerHTML = `<strong>Recomendación para ${ciudad}:</strong><br>${recomendacion}`;

        // === Guardar datos en el servidor ===
const datosFormulario = {
  estrato,
  tipoVivienda,
  tipoTecho,
  presupuesto,
  ciudad,
  recomendacion
};

fetch("/guardar", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(datosFormulario),
})
.then(res => res.json())
.then(data => console.log("✅ Datos guardados:", data))
.catch(err => console.error("❌ Error al guardar los datos:", err));


        

      }
     







